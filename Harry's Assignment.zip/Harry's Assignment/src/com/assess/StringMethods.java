package com.assess;

//StringPlay.java
class StringPlay {
 int convert;
 int max;

 public StringPlay() {
     // Empty constructor with public visibility
 }
}

//StringMethods.java
class StringMethods {

 public int convertToInt(StringPlay sp, String str) {
     int result = Integer.parseInt(str);
     sp.convert = result;
     return result;
 }

 public int getMax(StringPlay sp, String str, char ch) {
     int count = 0;
     for (int i = 0; i < str.length(); i++) {
         if (str.charAt(i) == ch) {
             count++;
         }
     }
     sp.max = count;
     return count;
 }
}

