package com.assess;

public class Main {
    public static void main(String[] args) {
        StringMethods sm = new StringMethods();
        StringPlay sp = new StringPlay();

        System.out.println(sm.getMax(sp, "fgfgfgf", 'g'));  // Output: 3
        System.out.println(sm.convertToInt(sp, "123"));     // Output: 123
    }
}

